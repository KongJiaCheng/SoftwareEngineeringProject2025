# from django.urls import path
# from . import views

# urlpatterns = [
#     path("upload/", views.upload, name="asset_upload"),
#     path("download/<int:pk>/", views.download, name="asset_download"),
# ]

