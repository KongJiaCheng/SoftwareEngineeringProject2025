# from django.contrib import admin
# from metadata.models import AssetMetadata

# # View and edit metadata in the Admin panel
# @admin.register(AssetMetadata) # modern way to register a model


