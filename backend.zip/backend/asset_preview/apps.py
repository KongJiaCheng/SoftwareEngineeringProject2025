from django.apps import AppConfig

class AssetPreviewConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "asset_preview"
    verbose_name = "Asset Preview"
